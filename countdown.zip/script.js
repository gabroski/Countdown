// შეცვალეთ ეს თარიღი თქვენთვის მნიშვნელოვანი მომენტით (ISO ფორმატში)
const TARGET_DATE = "2027-01-01T00:00:00";

const el = {
  days: document.getElementById('days'),
  hours: document.getElementById('hours'),
  minutes: document.getElementById('minutes'),
  seconds: document.getElementById('seconds'),
  status: document.getElementById('status')
};

const prev = { days: null, hours: null, minutes: null, seconds: null };

function pad(n) {
  return String(n).padStart(2, '0');
}

function setValue(node, key, value) {
  const text = pad(value);
  if (prev[key] !== text) {
    node.textContent = text;
    node.classList.remove('flip');
    // force reflow so the animation can replay
    void node.offsetWidth;
    node.classList.add('flip');
    prev[key] = text;
  }
}

function tick() {
  const now = new Date();
  const target = new Date(TARGET_DATE);
  const diff = target - now;

  if (diff <= 0) {
    setValue(el.days, 'days', 0);
    setValue(el.hours, 'hours', 0);
    setValue(el.minutes, 'minutes', 0);
    setValue(el.seconds, 'seconds', 0);
    el.status.innerHTML = '<strong>დადგა დრო!</strong>';
    return;
  }

  const totalSeconds = Math.floor(diff / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  setValue(el.days, 'days', days);
  setValue(el.hours, 'hours', hours);
  setValue(el.minutes, 'minutes', minutes);
  setValue(el.seconds, 'seconds', seconds);

  el.status.innerHTML = `დღეს არის <strong>${now.toLocaleDateString('ka-GE')}</strong>`;
}

tick();
setInterval(tick, 1000);
